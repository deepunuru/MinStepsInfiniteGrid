#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include "buffer_mgr.h"
#include "dberror.h"
#include "storage_mgr.h"

#define PAGE_LIMIT 30000
#define FRAME_LIMIT 300
#define K_LIMIT 10


typedef struct pageFrame{

	int pageNum;            /* the pageNum of page in the pageFile*/
	int fNum;           /* the number of the frame in the frame list*/
	bool dirty;              /* True(Dirty) = 1, False(not dirty) = 0*/
	int fixCount;           /* fixCount of the page based on the pinning/un-pinning request*/
	char *data;             /* Page Data*/
	struct pageFrame *next;
	struct pageFrame *prev;

}pageFrame;

/* A frame list with a pointer to head and tail node of type pageFrameNode.*/
typedef struct frameNode{

	pageFrame *head;    /* head node of the frame list. Should add new/updated/recently used node to head */
	pageFrame *tail;    /* tail node of the frame list. Should be the first/start to remove as per strategy*/

}frameNode;

/* Required data per buffer pool. Will be attached to BM_BufferPool->mgmtData*/
typedef struct bmPoolInfo{

	int numFrames;          /* filled number of frames in the frame list */
	int pagesRead;            /* number of read done on the buffer pool */
	int pagesWritten;           /* number of write done on the buffer pool */
	int pinCount;       /* total number of pinning done for the bm */
	void *stratData;
	int pageToFrame[PAGE_LIMIT];         /* an array from pageNumber to frameNumber. The size should be same as the size of the pageFile.*/
	int frameToPage[FRAME_LIMIT];        /* an array from frameNumber to pageNumber. The size should be same as the size of the frame list.*/
	int pageNumFreq[PAGE_LIMIT];     /* an array mappping pageNumber to pageFrequency. The size should be same as the size of the pageFile.*/
	bool dirtyFlags[FRAME_LIMIT];        /* dirtyflags of all the frames.*/
	int fixedCounts[FRAME_LIMIT];        /* fixed count of all the frames.*/

	frameNode *frames;      /* a pointer to the frame list of current buffer pool*/

}bmPoolInfo;

/*Page Replacement Strategies*/

pageFrame *searchPage(BM_BufferPool *const bm, BM_PageHandle *const page, const PageNumber pageNum)
{
	pageFrame *match = NULL;
	bmPoolInfo *poolInfo = (bmPoolInfo *)bm->mgmtData;
	pageFrame *currNode;
	currNode = poolInfo->frames->head;


	while (currNode != NULL)
	{
		if (currNode->pageNum == pageNum)
		{
			match = currNode;
			break;
		}
		currNode = currNode->next;
	}

	if ((poolInfo->pageToFrame)[pageNum] == -1)
	{
		return NULL;
	}
	else
	{
		if (match != NULL)
		{
			page->pageNum = pageNum;
			page->data = match->data;
			match->fixCount++;
			return match;
		}
		else
			return NULL;
	}

}

RC addNewFrame(BM_BufferPool *const bm, pageFrame *match, BM_PageHandle *const page, const PageNumber pageNum)
{
	SM_FileHandle fh;
	bmPoolInfo *poolInfo = (bmPoolInfo *)bm->mgmtData;
	int currStat;
	currStat = openPageFile((char *)(bm->pageFile), &fh);
	int k = sizeof(match->data);
	if (currStat == RC_OK)
	{
		if (match->dirty == 1)
		{
			if ((currStat = ensureCapacity(pageNum, &fh)) == RC_OK)
			{
				if ((currStat = writeBlock(match->pageNum, &fh, match->data)) == RC_OK)
				{
					(poolInfo->pagesWritten)++;
				}
				else
				{
					closePageFile(&fh);
					return currStat;
				}	
			}
			else
			{
				closePageFile(&fh);
				return currStat;
			}	
		}
		(poolInfo->pageToFrame)[match->pageNum] = -1;

		if ((currStat = ensureCapacity(pageNum, &fh)) == RC_OK)
		{
			if ((currStat = readBlock(pageNum, &fh, match->data)) == RC_OK)
			{
				page->pageNum = pageNum;
				page->data = match->data;
				(poolInfo->pagesRead)++;
				match->dirty = 0;
				match->fixCount = 1;
				match->pageNum = pageNum;

				(poolInfo->pageToFrame)[match->pageNum] = match->fNum;
				(poolInfo->frameToPage)[match->fNum] = match->pageNum;
				closePageFile(&fh);
				return RC_OK;
			}
			else
			{
				closePageFile(&fh);
				return currStat;
			}
		}
		else
		{
			closePageFile(&fh);
			return currStat;
		}
	}
	else
	{
		closePageFile(&fh);
		return currStat;
	}
}

void updateHeadNode(frameNode **node, pageFrame *fUpdate)
{
	pageFrame *head = (*node)->head;

	if (fUpdate == (*node)->head || head == NULL || fUpdate == NULL)
	{
		return;
	}
	else if (fUpdate == (*node)->tail)
	{
		pageFrame *tNode = ((*node)->tail)->prev;
		tNode->next = NULL;
		(*node)->tail = tNode;
	}
	else
	{
		fUpdate->prev->next = fUpdate->next;
		fUpdate->next->prev = fUpdate->prev;
	}

	fUpdate->next = head;
	head->prev = fUpdate;
	fUpdate->prev = NULL;
	(*node)->head = fUpdate;
	(*node)->head->prev = NULL;
	return;
}

RC pinPageFIFOStrategy(BM_BufferPool *const bm, BM_PageHandle *const page, const PageNumber pageNum)
{
	pageFrame *match = NULL;
	bmPoolInfo *poolInfo = (bmPoolInfo *)bm->mgmtData;
	int k = 0;
	if ((match = searchPage(bm, page, pageNum)) == NULL)
	{
		k = sizeof(match->data);
		if ((poolInfo->numFrames) < bm->numPages)
		{
			match = poolInfo->frames->head;
			int k = 0;
			while (k < poolInfo->numFrames)
			{
				match = match->next;
				++k;
			}
			(poolInfo->numFrames)++;
			updateHeadNode(&(poolInfo->frames), match);
			
		}
		else
		{
			match = poolInfo->frames->tail;
			while (match != NULL && match->fixCount != 0)
			{
				match = match->prev;
			}
			if (match == NULL)
				return RC_BUFFER_FULL;
			updateHeadNode(&(poolInfo->frames), match);
		}

		int currStat;
		int K = sizeof(match->data);
		currStat = addNewFrame(bm, match, page, pageNum);
		if (currStat == RC_OK)
		{
			return RC_OK;
		}
		else
			return currStat;
	}
	else 
		return RC_OK;
}

RC pinPageLRUStrategy(BM_BufferPool *const bm, BM_PageHandle *const page, const PageNumber pageNum)
{
	pageFrame *match = NULL;
	bmPoolInfo *poolInfo = (bmPoolInfo *)bm->mgmtData;

	if ((match = searchPage(bm, page, pageNum)) == NULL)
	{
		if ((poolInfo->numFrames) < bm->numPages)
		{
			match = poolInfo->frames->head;
			int k = 0;
			while (k < poolInfo->numFrames)
			{
				match = match->next;
				++k;
			}
			(poolInfo->numFrames)++;
		}
		else
		{
			match = poolInfo->frames->tail;
			while (match != NULL && match->fixCount != 0)
			{
				match = match->prev;
			}
			if (match == NULL)
				return RC_BUFFER_FULL;
		}

		int currStat;
		currStat = addNewFrame(bm, match, page, pageNum);
		if (currStat == RC_OK)
		{
			updateHeadNode(&(poolInfo->frames), match);
			return RC_OK;
		}
		else
			return currStat;
	}
	else
	{
		updateHeadNode(&(poolInfo->frames), match);
		return RC_OK;
	}
	
}

RC pinPageCLOCKStrategy(BM_BufferPool *const bm, BM_PageHandle *const page, const PageNumber pageNum)
{

}



/*Buffer Pool Functions*/
RC initBufferPool(BM_BufferPool *const bm, const char *const pageFileName, const int numPages, ReplacementStrategy strategy, void *stratData)
{
	SM_FileHandle fh;

	if (numPages > 0)
	{
		if (openPageFile((char *)pageFileName, &fh) == RC_OK)
		{
			bmPoolInfo *bPoolInfoNode = malloc(sizeof(bmPoolInfo));
			bPoolInfoNode->stratData = stratData;
			bPoolInfoNode->pagesWritten = 0;
			bPoolInfoNode->numFrames = 0;
			bPoolInfoNode->pagesRead = 0;
			bPoolInfoNode->pinCount = 0;
			int freqVal = PAGE_LIMIT*sizeof(int);
			int pageVal = PAGE_LIMIT * sizeof(int);
			int dirtyFlagVal = FRAME_LIMIT * sizeof(bool);
			int frameVal = FRAME_LIMIT * sizeof(int);
			memset(bPoolInfoNode->pageNumFreq, 0, freqVal);
			memset(bPoolInfoNode->frameToPage, NO_PAGE, frameVal);
			memset(bPoolInfoNode->pageToFrame, NO_PAGE, freqVal);
			memset(bPoolInfoNode->dirtyFlags, NO_PAGE, dirtyFlagVal);
			memset(bPoolInfoNode->fixedCounts, NO_PAGE, frameVal);
			
			bPoolInfoNode->frames = malloc(sizeof(frameNode));

			pageFrame *node = malloc(sizeof(pageFrame));
			node->pageNum = -1;
			node->fNum = 0;
			node->dirty = FALSE;
			node->fixCount = 0;
			node->data = calloc(PAGE_SIZE, sizeof(SM_PageHandle));
			node->next = NULL;
			node->prev = NULL;

			bPoolInfoNode->frames->head = bPoolInfoNode->frames->tail = node;
			//new statements introduced here
			node = NULL;
			free(node);

			int i = 1;
			while (i < numPages)
			{
				pageFrame *node = malloc(sizeof(pageFrame));
				node->pageNum = -1;
				node->fNum = 0;
				node->dirty = FALSE;
				node->fixCount = 0;
				node->data = calloc(PAGE_SIZE, sizeof(SM_PageHandle));
				node->next = NULL;
				node->prev = NULL;

				bPoolInfoNode->frames->tail->next = node;
				//new statements introduced here
				node = NULL;
				free(node);
				bPoolInfoNode->frames->tail->next->prev = bPoolInfoNode->frames->tail;
				bPoolInfoNode->frames->tail = bPoolInfoNode->frames->tail->next;
				bPoolInfoNode->frames->tail->fNum = i;
				++i;
			}

			bm->numPages = numPages;
			bm->pageFile = (char*) pageFileName;
			bm->strategy = strategy;
			bm->mgmtData = bPoolInfoNode;

			closePageFile(&fh);
			return RC_OK;
		}
		else
		{
			closePageFile(&fh);
			return RC_FILE_NOT_FOUND;
		}	
	}
	else
		return RC_INVALID_BM;
}

RC shutdownBufferPool(BM_BufferPool *const bm)
{
	if (!bm || bm->numPages <= 0)
		return RC_INVALID_BM;
	int status;
	status = forceFlushPool(bm);
	if (status == RC_OK)
	{
		bmPoolInfo *poolInfo = (bmPoolInfo *)bm->mgmtData;
		pageFrame  *currNode = poolInfo->frames->head;

		while (currNode != NULL)
		{
			currNode = currNode->next;
			free(poolInfo->frames->head->data);
			free(poolInfo->frames->head);
			poolInfo->frames->head = currNode;
		}

		poolInfo->frames->head = poolInfo->frames->tail = NULL;
		free(poolInfo->frames);
		free(poolInfo);
		bm->numPages = 0;
		return RC_OK;
	}
	else
		return status;
}

RC forceFlushPool(BM_BufferPool *const bm)
{
	bmPoolInfo *poolInfo = (bmPoolInfo *)bm->mgmtData;
	pageFrame *currNode = poolInfo->frames->head;

	SM_FileHandle fh;

	if (!bm || bm->numPages <= 0)
		return RC_INVALID_BM;

	if (openPageFile((char*)(bm->pageFile), &fh) == RC_OK)
	{
		while (currNode != NULL)
		{
			if (currNode->dirty == TRUE)
			{
				if (writeBlock(currNode->pageNum, &fh, currNode->data) == RC_OK)
				{
					currNode->dirty = 0;
					(poolInfo->pagesWritten)++;
				}
				else
				{
					closePageFile(&fh);
					return RC_WRITE_FAILED;
				}
			}
			currNode = currNode->next;
		}
		closePageFile(&fh);
		return RC_OK;
	}
	else
	{
		closePageFile(&fh);
		return RC_FILE_NOT_FOUND;
	}
}

RC markDirty(BM_BufferPool *const bm, BM_PageHandle *const page)
{
	bmPoolInfo *poolInfo = (bmPoolInfo *)bm->mgmtData;

	pageFrame *currNode = poolInfo->frames->head;
	pageFrame *match = NULL;

	if (!bm || bm->numPages <= 0)
		return RC_INVALID_BM;

	while (currNode != NULL)
	{
		if (currNode->pageNum == page->pageNum)
		{
			match = currNode;
			break;
		}	
		currNode = currNode->next;
	}

	if (match != NULL)
	{
		match->dirty = 1;
		return RC_OK;
	}
	else
		return RC_NON_EXISTING_PAGE_IN_FRAME;

}

RC unpinPage(BM_BufferPool *const bm, BM_PageHandle *const page)
{
	bmPoolInfo *poolInfo = (bmPoolInfo *)bm->mgmtData;

	pageFrame *currNode = poolInfo->frames->head;
	pageFrame *match = NULL;

	if (!bm || bm->numPages <= 0)
		return RC_INVALID_BM;

	while (currNode != NULL)
	{
		if (currNode->pageNum == page->pageNum)
		{
			match = currNode;
			break;
		}
		currNode = currNode->next;
	}

	if (match != NULL)
	{
		if (match->fixCount > 0)
		{
			match->fixCount--;
			return RC_OK;
		}
		else
			return RC_NON_EXISTING_PAGE_IN_FRAME;
	}
	else
	return RC_NON_EXISTING_PAGE_IN_FRAME;

}

RC forcePage(BM_BufferPool *const bm, BM_PageHandle *const page)
{
	bmPoolInfo *poolInfo = (bmPoolInfo *)bm->mgmtData;

	pageFrame *currNode = poolInfo->frames->head;
	pageFrame *match = NULL;

	if (!bm || bm->numPages <= 0)
		return RC_INVALID_BM;

	while (currNode != NULL)
	{
		if (currNode->pageNum == page->pageNum)
		{
			match = currNode;
			break;
		}
		currNode = currNode->next;
	}

	SM_FileHandle fh;

	if (openPageFile ((char*)(bm->pageFile), &fh) == RC_OK)
	{
		if (match != NULL)
		{
			if (writeBlock(match->pageNum, &fh, match->data) == RC_OK)
			{
				poolInfo->pagesWritten++;
				closePageFile(&fh);
				return RC_OK;
			}
			else
			{
				closePageFile(&fh);
				return RC_WRITE_FAILED;
			}	
		}
		else
		{
			closePageFile(&fh);
			return RC_NON_EXISTING_PAGE_IN_FRAME;
		}
			
	}
	else
	{
		closePageFile(&fh);
		return RC_FILE_NOT_FOUND;
	}
}

RC pinPage(BM_BufferPool *const bm, BM_PageHandle *const page, const PageNumber pageNum)
{
	if (!bm || bm->numPages <= 0){
		return RC_INVALID_BM;
	}
	if (pageNum < 0)
		return RC_READ_NON_EXISTING_PAGE;

	switch (bm->strategy)
	{
	case RS_FIFO:
		return pinPageFIFOStrategy(bm, page, pageNum);
		break;
	case RS_LRU:
		return pinPageLRUStrategy(bm, page, pageNum);
		break;
	case RS_CLOCK:
		return pinPageCLOCKStrategy(bm, page, pageNum);
		break;
	default:
		return RC_INVALID_STRATEGY;
		break;
	}
	return RC_OK;
}


/*Statistics Functions*/

PageNumber *getFrameContents(BM_BufferPool *const bm)
{
	return ((bmPoolInfo *)bm->mgmtData)->frameToPage;
}

bool *getDirtyFlags(BM_BufferPool *const bm)
{
	bmPoolInfo *poolInfo = (bmPoolInfo *)bm->mgmtData;
	pageFrame *currNode = poolInfo->frames->head;

	while (currNode != NULL)
	{
		(poolInfo->dirtyFlags)[currNode->fNum] = currNode->dirty;
		currNode = currNode->next;
	}
	return poolInfo->dirtyFlags;
}

int *getFixCounts(BM_BufferPool *const bm)
{
	bmPoolInfo *poolInfo = (bmPoolInfo *)bm->mgmtData;
	pageFrame *currNode = poolInfo->frames->head;

	while (currNode != NULL)
	{
		(poolInfo->fixedCounts)[currNode->fNum] = currNode->fixCount;
		currNode = currNode->next;
	}
	return poolInfo->fixedCounts;
}

int getNumReadIO(BM_BufferPool *const bm)
{
	return ((bmPoolInfo *)bm->mgmtData)->pagesRead;
}

int getNumWriteIO(BM_BufferPool *const bm)
{
	return ((bmPoolInfo *)bm->mgmtData)->pagesWritten;
}
