#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "dberror.h"
#include "storage_mgr.h"


void initStorageManager (void)
{
	printf("Storage Manager Initialized...\n");
}

/*
*************** Page Manipulation Functions ******************
*/


/***********************************************************************************************
* Function Name: createPageFile
*
* Description:
*	Create a new page file and fills this newly created page with '\0' bytes.
* Parameters:
*	char *fileName: Pointer to file name
*
* Return:
*	RC: return code
*
* Author:
*	Sandeep Nurukurthi <snurukurthi@hawk.iit.edu>
*	Chaitanya Sistla <csistla@hawk.iit.edu>	
*
* History:
*	Date		Name											Content
*	----------  ----------------------------------------------  --------------------------------
*	2016-09-20	Chaitanya Sistla <csistla@hawk.iit.edu>			Function definition
*	2016-09-25	Sandeep Nurukurthi <snurukurthi@hawk.iit.edu>	Function headers and testing
*
*************************************************************************************************/
RC createPageFile (char *fileName)
{
    
    char *pgPtr = (char *)calloc(PAGE_SIZE,sizeof(char));	//allocate one page space with the initial value '\0'
	char *fPgPtr = (char *)calloc(PAGE_SIZE, sizeof(char));

	FILE *fPtr = fopen(fileName, "w");						//create the file.										
	
	strcat(pgPtr, "1\n");
	int writeRes = fwrite(pgPtr, sizeof(char), PAGE_SIZE, fPtr);
	int pgRes = fwrite(fPgPtr, sizeof(char), PAGE_SIZE, fPtr);

	if (writeRes == 0 || pgRes == 0)
	{
		free(pgPtr);
		free(fPgPtr);
		fclose(fPtr);
		return RC_WRITE_FAILED;
	}    
	else
	{
		free(pgPtr);
		free(fPgPtr);
		fclose(fPtr);
		return RC_OK;
	}    											
}


/***********************************************************************************************
* Function Name: openPageFile
*
* Description:
*	Open an existing page file 
*	If the file does not exist, return RC_FILE_NOT_FOUND
*	If the file exists, populate file handle with information about the file
* Parameters:
*	char *fileName: Pointer to file name
*   SM_FileHandle *fHandle: Pointer to file handle
*
* Return:
*	RC: return code
*
* Author:
*	Sandeep Nurukurthi <snurukurthi@hawk.iit.edu>
*	Chaitanya Sistla <csistla@hawk.iit.edu>
*
* History:
*	Date		Name											Content
*	----------  ----------------------------------------------  --------------------------------
*	2016-09-20	Chaitanya Sistla <csistla@hawk.iit.edu>			Function definition
*	2016-09-25	Sandeep Nurukurthi <snurukurthi@hawk.iit.edu>	Function headers and testing
*
*************************************************************************************************/
RC openPageFile (char *fileName, SM_FileHandle *fHandle)
{
	FILE *fptr = fopen(fileName, "r+");

	if (fptr == NULL)
	{
		fclose(fptr);
		return RC_FILE_NOT_FOUND;
	}	
	else
	{
		char *data;
		data = (char *)calloc(PAGE_SIZE, sizeof(char));
		fgets(data, PAGE_SIZE, fptr);
		data = strtok(data, "\n");
		fHandle->fileName = fileName;
		fHandle->totalNumPages = atoi(data);
		fHandle->curPagePos = 0;
		fHandle->mgmtInfo = fptr;

		free(data);
		return RC_OK;
	}
}


/***********************************************************************************************
* Function Name: closePageFile
*
* Description:
*	Closes an open page file
*
* Parameters:
*   SM_FileHandle *fHandle: Pointer to file handle
*
* Return:
*	RC: return code
*
* Author:
*	Sandeep Nurukurthi <snurukurthi@hawk.iit.edu>
*	Chaitanya Sistla <csistla@hawk.iit.edu>
*
* History:
*	Date		Name											Content
*	----------  ----------------------------------------------  --------------------------------
*	2016-09-20	Chaitanya Sistla <csistla@hawk.iit.edu>			Function definition
*	2016-09-25	Sandeep Nurukurthi <snurukurthi@hawk.iit.edu>	Function headers and testing
*
*************************************************************************************************/
RC closePageFile (SM_FileHandle *fHandle)
{
	int res = fclose(fHandle->mgmtInfo);

	if (!res)
		return RC_OK;
	else
		return RC_FILE_NOT_FOUND;
}

/***********************************************************************************************
* Function Name: destroyPageFile
*
* Description:
*	Destroys(delete) a page file
*
* Parameters:
*	char *fileName: file name
*
* Return:
*	RC: return code
*
* Author:
*	Sandeep Nurukurthi <snurukurthi@hawk.iit.edu>
*	Chaitanya Sistla <csistla@hawk.iit.edu>
*
* History:
*	Date		Name											Content
*	----------  ----------------------------------------------  --------------------------------
*	2016-09-20	Chaitanya Sistla <csistla@hawk.iit.edu>			Function definition
*	2016-09-25	Sandeep Nurukurthi <snurukurthi@hawk.iit.edu>	Function headers and testing
*
*************************************************************************************************/
RC destroyPageFile (char *fileName){
	
	int res = remove(fileName);
    if(!res)
        return RC_OK;
    else
		return RC_FILE_NOT_FOUND;
}

/*
*************** Block Reading Functions ******************
*/

/***********************************************************************************************
* Function Name: readBlock
*
* Description:
*	Reads a block from the file and stores its content int the memory pointed to by the page handle
*
* Parameters:
*	int pageNum: Indicates page number
*   SM_FileHandle *fHandle: Pointer to file handle
*   SM_PageHandle memPage: Indicates page handle
*
* Return:
*	RC: return code
*
* Author:
*	Sandeep Nurukurthi <snurukurthi@hawk.iit.edu>
*	Chaitanya Sistla <csistla@hawk.iit.edu>
*
* History:
*	Date		Name											Content
*	----------  ----------------------------------------------  --------------------------------
*	2016-09-20	Chaitanya Sistla <csistla@hawk.iit.edu>			Function definition
*	2016-09-25	Sandeep Nurukurthi <snurukurthi@hawk.iit.edu>	Function headers and testing
*
*************************************************************************************************/
RC readBlock (int pageNum, SM_FileHandle *fHandle, SM_PageHandle memPage)
{
	int seekRes;
	size_t blockSize;

	if (pageNum > fHandle->totalNumPages || pageNum < 0)
		return RC_PAGE_NUMBER_OUT_OF_BOUNDRY;
	else
	{
		if (fHandle->mgmtInfo == NULL)
			return RC_FILE_NOT_FOUND;
		else
		{
			seekRes = fseek(fHandle->mgmtInfo, (pageNum + 1)*PAGE_SIZE*sizeof(char), SEEK_SET);
			if (seekRes == 0)
			{
				blockSize = fread(memPage, sizeof(char), PAGE_SIZE, fHandle->mgmtInfo);
				fHandle->curPagePos = pageNum;
				return RC_OK;
			}
			else
				return RC_SET_POINTER_FAILED;
		}
	}  
}

/***********************************************************************************************
* Function Name: getBlockPos
*
* Description:
*	Returns currrent page position in a file
*
* Parameters:
*   SM_FileHandle *fHandle: Pointer to file handle
*
* Return:
*	int: Current Page Position
*
* Author:
*	Sandeep Nurukurthi <snurukurthi@hawk.iit.edu>
*	Chaitanya Sistla <csistla@hawk.iit.edu>
*
* History:
*	Date		Name											Content
*	----------  ----------------------------------------------  --------------------------------
*	2016-09-20	Chaitanya Sistla <csistla@hawk.iit.edu>			Function definition
*	2016-09-25	Sandeep Nurukurthi <snurukurthi@hawk.iit.edu>	Function headers and testing
*
*************************************************************************************************/
int getBlockPos (SM_FileHandle *fHandle){
    return fHandle ->curPagePos;
}

/***********************************************************************************************
* Function Name: readFirstBlock
*
* Description:
*	Read first block in a file
*
* Parameters:
*   SM_FileHandle *fHandle: Pointer to file handle
*   SM_PageHandle memPage: Implies page handle
*
* Return:
*	RC: return value
*
* Author:
*	Sandeep Nurukurthi <snurukurthi@hawk.iit.edu>
*	Chaitanya Sistla <csistla@hawk.iit.edu>
*
* History:
*	Date		Name											Content
*	----------  ----------------------------------------------  --------------------------------
*	2016-09-20	Chaitanya Sistla <csistla@hawk.iit.edu>			Function definition
*	2016-09-25	Sandeep Nurukurthi <snurukurthi@hawk.iit.edu>	Function headers and testing
*
*************************************************************************************************/
RC readFirstBlock (SM_FileHandle *fHandle, SM_PageHandle memPage){
    return readBlock(0, fHandle, memPage);
}

/***********************************************************************************************
* Function Name: readPreviousBlock
*
* Description:
*	Read Previous block of a file
*
* Parameters:
*   SM_FileHandle *fHandle: Pointer to file handle
*   SM_PageHandle memPage: Implies page handle
*
* Return:
*	RC: return value
*
* Author:
*	Sandeep Nurukurthi <snurukurthi@hawk.iit.edu>
*	Chaitanya Sistla <csistla@hawk.iit.edu>
*
* History:
*	Date		Name											Content
*	----------  ----------------------------------------------  --------------------------------
*	2016-09-20	Chaitanya Sistla <csistla@hawk.iit.edu>			Function definition
*	2016-09-25	Sandeep Nurukurthi <snurukurthi@hawk.iit.edu>	Function headers and testing
*
*************************************************************************************************/
RC readPreviousBlock (SM_FileHandle *fHandle, SM_PageHandle memPage){
    int prePage=(fHandle->curPagePos-1);
    return readBlock(prePage, fHandle, memPage);
}

/***********************************************************************************************
* Function Name: readCurrentBlock
*
* Description:
*	Read current block from a file
*
* Parameters:
*   SM_FileHandle *fHandle: Pointer to file handle
*   SM_PageHandle memPage: Implies page handle
*
* Return:
*	RC: return value
*
* Author:
*	Sandeep Nurukurthi <snurukurthi@hawk.iit.edu>
*	Chaitanya Sistla <csistla@hawk.iit.edu>
*
* History:
*	Date		Name											Content
*	----------  ----------------------------------------------  --------------------------------
*	2016-09-20	Chaitanya Sistla <csistla@hawk.iit.edu>			Function definition
*	2016-09-25	Sandeep Nurukurthi <snurukurthi@hawk.iit.edu>	Function headers and testing
*
*************************************************************************************************/
RC readCurrentBlock (SM_FileHandle *fHandle, SM_PageHandle memPage){
    return readBlock(fHandle->curPagePos, fHandle, memPage);
}

/***********************************************************************************************
* Function Name: readNextBlock
*
* Description:
*	Read next block from current position of a file
*
* Parameters:
*   SM_FileHandle *fHandle: Pointer to file handle
*   SM_PageHandle memPage: Implies page handle
*
* Return:
*	RC: return value
*
* Author:
*	Sandeep Nurukurthi <snurukurthi@hawk.iit.edu>
*	Chaitanya Sistla <csistla@hawk.iit.edu>
*
* History:
*	Date		Name											Content
*	----------  ----------------------------------------------  --------------------------------
*	2016-09-20	Chaitanya Sistla <csistla@hawk.iit.edu>			Function definition
*	2016-09-25	Sandeep Nurukurthi <snurukurthi@hawk.iit.edu>	Function headers and testing
*
*************************************************************************************************/
RC readNextBlock (SM_FileHandle *fHandle, SM_PageHandle memPage){
    int nextPage=fHandle->totalNumPages+1;
    return readBlock(nextPage, fHandle, memPage);
}

/***********************************************************************************************
* Function Name: readLastBlock
*
* Description:
*	Read last block of a file
*
* Parameters:
*   SM_FileHandle *fHandle: Pointer to file handle
*   SM_PageHandle memPage: Implies page handle
*
* Return:
*	RC: return value
*
* Author:
*	Sandeep Nurukurthi <snurukurthi@hawk.iit.edu>
*	Chaitanya Sistla <csistla@hawk.iit.edu>
*
* History:
*	Date		Name											Content
*	----------  ----------------------------------------------  --------------------------------
*	2016-09-20	Chaitanya Sistla <csistla@hawk.iit.edu>			Function definition
*	2016-09-25	Sandeep Nurukurthi <snurukurthi@hawk.iit.edu>	Function headers and testing
*
*************************************************************************************************/
RC readLastBlock (SM_FileHandle *fHandle, SM_PageHandle memPage){
    return readBlock(fHandle->totalNumPages, fHandle, memPage);
}

/***********************************************************************************************
* Function Name: readLastBlock
*
* Description:
*	Write blocks to a page file
*	Write pages to disk using either the current positiono or an absolute position as reference
*
* Parameters:
*	int pageNum: Indicates page number
*   SM_FileHandle *fHandle: Pointer to file handle
*   SM_PageHandle memPage: Implies page handle
*
* Return:
*	RC: return value
*
* Author:
*	Sandeep Nurukurthi <snurukurthi@hawk.iit.edu>
*	Chaitanya Sistla <csistla@hawk.iit.edu>
*
* History:
*	Date		Name											Content
*	----------  ----------------------------------------------  --------------------------------
*	2016-09-20	Chaitanya Sistla <csistla@hawk.iit.edu>			Function definition
*	2016-09-25	Sandeep Nurukurthi <snurukurthi@hawk.iit.edu>	Function headers and testing
*
*************************************************************************************************/
RC writeBlock (int pageNum, SM_FileHandle *fHandle, SM_PageHandle memPage)
{
	int seekRes;
	size_t blockSize;

	if (pageNum > (fHandle->totalNumPages) || (pageNum < 0))
		return RC_PAGE_NUMBER_OUT_OF_BOUNDRY;
	else
	{
		seekRes = fseek(fHandle->mgmtInfo, (pageNum + 1)*PAGE_SIZE*sizeof(char), SEEK_SET);
		if (seekRes == 0)
		{
			blockSize = fwrite(memPage, sizeof(char), PAGE_SIZE, fHandle->mgmtInfo);
			fHandle->curPagePos = pageNum;
			return RC_OK;
		}
		else
			return RC_SET_POINTER_FAILED;
	} 
}

/***********************************************************************************************
* Function Name: writeCurrentBlock
*
* Description:
*	Writes current block to file
*
* Parameters:
*   SM_FileHandle *fHandle: Pointer to file handle
*   SM_PageHandle memPage: Implies page handle
*
* Return:
*	RC: return value
*
* Author:
*	Sandeep Nurukurthi <snurukurthi@hawk.iit.edu>
*	Chaitanya Sistla <csistla@hawk.iit.edu>
*
* History:
*	Date		Name											Content
*	----------  ----------------------------------------------  --------------------------------
*	2016-09-20	Chaitanya Sistla <csistla@hawk.iit.edu>			Function definition
*	2016-09-25	Sandeep Nurukurthi <snurukurthi@hawk.iit.edu>	Function headers and testing
*
*************************************************************************************************/
RC writeCurrentBlock (SM_FileHandle *fHandle, SM_PageHandle memPage){
    return writeBlock(fHandle->curPagePos, fHandle, memPage);
}

/***********************************************************************************************
* Function Name: appendEmptyBlock
*
* Description:
*	Appends an empty block to the end of the file
*	Increases the number of pages in the file by one
*	The appended page would be filled with '\0' bytes
*
* Parameters:
*   SM_FileHandle *fHandle: Pointer to file handle
*
* Return:
*	RC: return value
*
* Author:
*	Sandeep Nurukurthi <snurukurthi@hawk.iit.edu>
*	Chaitanya Sistla <csistla@hawk.iit.edu>
*
* History:
*	Date		Name											Content
*	----------  ----------------------------------------------  --------------------------------
*	2016-09-20	Chaitanya Sistla <csistla@hawk.iit.edu>			Function definition
*	2016-09-25	Sandeep Nurukurthi <snurukurthi@hawk.iit.edu>	Function headers and testing
*
*************************************************************************************************/
RC appendEmptyBlock (SM_FileHandle *fHandle)
{
	int seekRes;
	size_t blockSize;
	SM_PageHandle ph;
	ph = (char *)calloc(PAGE_SIZE, sizeof(char));
	seekRes = fseek(fHandle->mgmtInfo, (fHandle->totalNumPages + 1)*PAGE_SIZE*sizeof(char), SEEK_END);

	if (seekRes == 0)
	{
		blockSize = fwrite(ph, sizeof(char), PAGE_SIZE, fHandle->mgmtInfo);
		fHandle->totalNumPages = fHandle->totalNumPages + 1;
		fHandle->curPagePos = fHandle->totalNumPages;
		rewind(fHandle->mgmtInfo);
		fprintf(fHandle->mgmtInfo, "%d\n", fHandle->totalNumPages);
		fseek(fHandle->mgmtInfo, (fHandle->totalNumPages + 1)*PAGE_SIZE*sizeof(char), SEEK_SET);
		free(ph);
		return RC_OK;
	}
	else
	{
		free(ph);
		return RC_WRITE_FAILED;
	}
}

/***********************************************************************************************
* Function Name: ensureCapacity
*
* Description:
*	If the size of the file is less than the value specified for 'numberOfPages' variable, then this function would increase the size to the desired value
*
* Parameters:
*	int numberOfPages: Specifies number of Pages
*   SM_FileHandle *fHandle: Pointer to file handle
*
* Return:
*	RC: return value
*
* Author:
*	Sandeep Nurukurthi <snurukurthi@hawk.iit.edu>
*	Chaitanya Sistla <csistla@hawk.iit.edu>
*
* History:
*	Date		Name											Content
*	----------  ----------------------------------------------  --------------------------------
*	2016-09-20	Chaitanya Sistla <csistla@hawk.iit.edu>			Function definition
*	2016-09-25	Sandeep Nurukurthi <snurukurthi@hawk.iit.edu>	Function headers and testing
*
*************************************************************************************************/
RC ensureCapacity (int numberOfPages, SM_FileHandle *fHandle){
	if (numberOfPages > fHandle->totalNumPages)
	{
		for (int x = 0; x < (numberOfPages - fHandle->totalNumPages); x++)
		{
			appendEmptyBlock(fHandle);
		}
	}        
    return RC_OK;
}